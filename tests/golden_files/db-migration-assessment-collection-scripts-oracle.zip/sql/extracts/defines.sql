--
-- Copyright 2024 Google LLC
--
-- Licensed under the Apache License, Version 2.0 (the "License").
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--     https://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
--
spool &outputdir/opdb__defines__&v_tag
prompt appinfo is OFF and set to "DB MIGRATION ASSESSMENT"
SHOW appinfo
SHOW colsep
SHOW define
SHOW echo
SHOW embedded
SHOW feedback
SHOW head
SHOW headsep
SHOW lines
SHOW numwidth
SHOW pagesize
SHOW pause
SHOW scan
SHOW time
SHOW timing
SHOW trimspool
SHOW underline
SHOW verify
SHOW wrap
prompt p_sp_script        = &p_sp_script
prompt v_a_con_id         = &v_a_con_id
prompt v_b_con_id         = &v_b_con_id
prompt v_c_con_id         = &v_c_con_id
prompt v_h_con_id         = &v_h_con_id
prompt v_data_type_exp    = &v_data_type_exp
prompt v_db_container_col = &v_db_container_col
prompt v_dbid             = &v_dbid
prompt v_dma_source_id    = &v_dma_source_id
prompt v_dbname           = &v_dbname
prompt v_dbparam_dflt_col = &v_dbparam_dflt_col
prompt v_dbversion        = &v_dbversion
prompt v_dopluggable      = &v_dopluggable
prompt v_editionable_col  = &v_editionable_col
prompt v_hora             = &v_hora
prompt v_host             = &v_host
prompt v_inst             = &v_inst
prompt v_io_function_sql  = &v_io_function_sql
prompt v_is_container     = &v_is_container
prompt v_max_snapid       = &v_max_snapid
prompt v_min_snapid       = &v_min_snapid
prompt v_tblprefix        = &v_tblprefix
prompt v_umf_test         = &v_umf_test
prompt Applies to STATSPACK collections only:
prompt v_max_snaptime     = &v_max_snaptime
prompt v_min_snaptime     = &v_min_snaptime
spool off
